// config/store.js
import { deviceConfigPriorityDir } from "../lib/Constants.js";
const store = {
    settings: {
        file: 'settings.json',
        default: {
            zwave: {
                deviceConfigPriorityDir,
                enableSoftReset: true,
            },
        },
    },
    scenes: { file: 'scenes.json', default: [] },
    nodes: { file: 'nodes.json', default: {} },
    users: { file: 'users.json', default: [] },
};
export default store;
